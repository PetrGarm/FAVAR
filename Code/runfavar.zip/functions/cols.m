function out=cols(x)
out=size(x,2);